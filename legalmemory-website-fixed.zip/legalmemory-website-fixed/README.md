# Legal Memory AI Website

Next.js + Tailwind project for Legal Memory AI homepage.