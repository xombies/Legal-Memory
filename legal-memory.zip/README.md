# Legal Memory

Next.js + Tailwind project for https://legalmemory.com
